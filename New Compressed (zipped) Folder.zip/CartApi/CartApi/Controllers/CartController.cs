﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace CartApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private IConfiguration configuration;
        public CartController(IConfiguration configuration)
        {
            this.configuration = configuration;
        }
        [HttpPost("",Name ="AddToCart")]
        public ActionResult AddToCart
    }
}