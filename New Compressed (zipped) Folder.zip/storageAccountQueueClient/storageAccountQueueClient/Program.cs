using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.Storage.Queue;
using Microsoft.Azure.Storage;
using Microsoft.Azure;

namespace storageAccountQueueClient
{
    class Program
    {
        static void Main(string[] args)
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(
                CloudConfigurationManager.GetSetting("ConnectionString"));
            CloudQueueClient queueClient = storageAccount.CreateCloudQueueClient();
            CloudQueue queue= queueClient.GetQueueReference("myqueue");
            CloudQueueMessage mes = queue.GetMessage(TimeSpan.FromMinutes(4.0));
            IEnumerable<CloudQueueMessage> messages = queue.GetMessages(20, TimeSpan.FromMinutes(5.0));
            //foreach(CloudQueueMessage message in queue.GetMessages(20,TimeSpan.FromMinutes(5.0)))
            //{
            //    queue.DeleteMessage(message);
            //}

            Console.ReadLine();


            
        }
    }
}
