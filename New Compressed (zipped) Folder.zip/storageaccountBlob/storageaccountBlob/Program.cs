﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Azure.Storage;
using Microsoft.Azure.Storage.Blob;

namespace storageaccountBlob
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Azure Blob Storage - .NET quickstart sample\n");
            ProcessAsync().GetAwaiter().GetResult();
            Console.WriteLine("Press any key to exit the sample application.");
            Console.ReadLine();
        }
        public static async Task ProcessAsync()
        {
            string choice;
            Console.WriteLine("Enter your choice");
            choice = Console.ReadLine();
            switch(choice)
            {
                case "1":
                    uploadblob().GetAwaiter().GetResult();
                    break;
                case "2":


            }
                
            string connectionString = Environment.GetEnvironmentVariable("CONNECT_STR");
            CloudStorageAccount storageAccount;
            if (CloudStorageAccount.TryParse(connectionString, out storageAccount))
            {
                CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
                CloudBlobContainer container = blobClient.GetContainerReference("mycontainer");
                await container.CreateIfNotExistsAsync();

                BlobContainerPermissions permissions = new BlobContainerPermissions
                {
                    PublicAccess = BlobContainerPublicAccessType.Blob
                };
                await container.SetPermissionsAsync(permissions);

                string localPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                string filename = "myfile.txt";
                string filepath = Path.Combine(localPath, filename);
                File.WriteAllText(filepath, "Hello World!!");

                CloudBlockBlob blockBlob = container.GetBlockBlobReference(filename);
                await blockBlob.UploadFromFileAsync(filepath);
            }
            else
            {
                Console.WriteLine("A connection string has not been defined in the system environment variables. " +
        "Add an environment variable named 'CONNECT_STR' with your storage " +
        "connection string as a value.");
                Console.WriteLine("Press any key to exit the application.");
                Console.ReadLine();
            }
        }
    }
}
