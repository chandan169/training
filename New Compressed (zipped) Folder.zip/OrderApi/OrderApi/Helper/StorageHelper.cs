﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.Storage;

namespace OrderApi.Helper
{
    public class StorageHelper
    {
        string connectionString
            public StorageHelper(string )
        {
                
        }

    }
}
