using Microsoft.Azure.Storage.Queue;
using Microsoft.Azure;
using Microsoft.Azure.Storage;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace storageaccountqueueframe
{
    class Program
    {
        static void Main(string[] args)
        {
            QueueOperationAsync();
            //parse the connection string
            //CloudStorageAccount storageAccount = CloudStorageAccount.Parse(
            // CloudConfigurationManager.GetSetting("StorageConnectionString"));

            //create the queue client to interact with the storage accout queue
            //CloudQueueClient queueClient = storageAccount.CreateCloudQueueClient();

            //get reference of queue
            //CloudQueue queue = queueClient.GetQueueReference("myqueue");

            //create if doesnot exist
            //queue.CreateIfNotExists();

            ////enter message to queue
            ////CloudQueueMessage message = new CloudQueueMessage("Hello World");
            ////queue.AddMessage(message);

            //// peek message function is used to read the message without deleting it
            //CloudQueueMessage peekMessage = queue.PeekMessage();
            //Console.WriteLine(peekMessage.AsString);

            ////update the meessage

            //CloudQueueMessage getmessage = queue.GetMessage();
            //Console.WriteLine(getmessage.AsString);
            //getmessage.SetMessageContent2("Updated content.", false);
            //queue.UpdateMessage(getmessage, TimeSpan.FromSeconds(10.0), MessageUpdateFields.Content | MessageUpdateFields.Visibility);
            //CloudQueueMessage updatedMessage = queue.GetMessage();            
            //Console.WriteLine(updatedMessage.AsString);

            Console.ReadLine();
        }

        public static async Task QueueOperationAsync()
        {
            //parse the connection string
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(
             CloudConfigurationManager.GetSetting("StorageConnectionString"));

            //create the queue client to interact with the storage accout queue
            CloudQueueClient queueClient = storageAccount.CreateCloudQueueClient();

            //get reference of queue
            CloudQueue queue = queueClient.GetQueueReference("myqueue");
            if (await queue.CreateIfNotExistsAsync())
            {
                Console.WriteLine("Queue {0} is created", queue.Name);
            }
            else
            {
                Console.WriteLine("Queue {0} is already there", queue.Name);
            }
            for (int i = 1; i < 25; i++)
            {
                try
                {
                    CloudQueueMessage message = new CloudQueueMessage("this is second set of message "+ i.ToString());
                    await queue.AddMessageAsync(message);
                    Console.WriteLine("{0} Message added", i);
                    Thread.Sleep(5000);
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex);
                }
            }
            //CloudQueueMessage retriveMessage = await queue.GetMessageAsync();
            //Console.WriteLine("Retrived message is {0}", retriveMessage.AsString);
            ////async delete the message
            //await queue.DeleteMessageAsync(retriveMessage);
            //Console.WriteLine("Message deleted");
        }
    }
}
