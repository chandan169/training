﻿using System;

namespace fanoutSubscriber

{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
