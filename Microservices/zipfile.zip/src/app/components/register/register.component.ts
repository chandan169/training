import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators, FormGroup } from '@angular/forms';
import { UserService } from 'src/app/services/user.service';
import { User } from 'src/app/models/User';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  userform: FormGroup
  constructor(private fb: FormBuilder, private userSvc:UserService) {
    this.userform=this.fb.group({
      username:new FormControl("", Validators.required),
      password:new FormControl("", Validators.compose([Validators.required, Validators.minLength(8)])),
      fullname:new FormControl("", Validators.required),
      email:new FormControl("", Validators.compose([Validators.required, Validators.email]))
      
    })
}

  ngOnInit() {
  }

  public get Username(){
    return this.userform.controls["username"];
  }
  public get Password(){
    return this.userform.controls["password"];
  }
  public get Fullname(){
    return this.userform.controls["fullname"];
  }
  public get Email(){
    return this.userform.controls["email"];
  }
  
  register(){
    if(this.userform.valid){//save
      let user:User=this.userform.value;
      this.userSvc.addUser(user)
      .subscribe(
        result=>{console.log(result); alert("registered successfully");},
        err=>{console.log(err); alert("error in registering user")}
      )
    }
    else{alert("invalid data ")}
  }
}
