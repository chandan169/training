import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validator, FormControl, Validators} from '@angular/forms'
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm:FormGroup

  constructor(private fb: FormBuilder, private userSvc:UserService, private router:Router) {
    this.loginForm = this.fb.group({
      username: new FormControl("", Validators.required),
      password: new FormControl("", Validators.compose([Validators.required, Validators.minLength(8)])),

    })
   }

  ngOnInit() {
  }

  public get Username() {
    return this.loginForm.controls["username"];
  }
  public get Password() {
    return this.loginForm.controls["password"];
  }

  login() {
    if (this.loginForm.valid) {
      this.userSvc.getToken(this.loginForm.value)
      .subscribe(
        res=>{
          this.userSvc.saveUserState(res);
          this.router.navigate(['/']);
        },
        err => { alert("error in validating") }
      )
     }
    else { alert("Invalid creds") }
  }
}
