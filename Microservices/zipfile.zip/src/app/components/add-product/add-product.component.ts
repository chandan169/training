import { Component, OnInit } from '@angular/core';
import { CatalogItem } from 'src/app/models/catalog-item';
import { CatalogService } from 'src/app/services/catalog.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
  product:CatalogItem
  constructor(private catalogSvc: CatalogService) { 
    this.product={
      name:"",
      price:0,
      quantity:0,
      reorderLevel:0,
      manufacturingDate:undefined
    }
  }


  ngOnInit() {
  }
  save(frm,img)
  {
    console.log(frm)
    if(frm.valid){
      let formData:FormData = new FormData();
      formData.append("name",this.product.name);
      formData.append("price",this.product.price.toString());
      formData.append("quantity",this.product.quantity.toString());
      formData.append("mDate",this.product.manufacturingDate);
      formData.append("rLevel",this.product.reorderLevel.toString());
      formData.append("image",img.files[0],img.files[0].name);
      //save to the server using web api
      this.catalogSvc.addProduct(formData).subscribe(
        result=>{
          console.log(result);
          alert("Added successfully");
        },
        err=>{
          console.log(err);
          alert("error in adding product")
          
        }
      )
    }
    else{
      alert("invalid form data");
    }

  }
}
