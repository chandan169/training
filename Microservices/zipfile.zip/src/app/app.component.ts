import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from './services/user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  currentUser:any;

  constructor(private userSvc:UserService, private router:Router)
  {
    this.userSvc.currentUser.subscribe(user=>this.currentUser=user)
  }

  logout(){
    this.userSvc.removeUserState();
    this.router.navigate(['/login']);
  }
}
