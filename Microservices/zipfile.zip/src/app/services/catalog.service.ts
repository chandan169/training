import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { AddProductComponent } from '../components/add-product/add-product.component';
import { Observable } from 'rxjs';
import { CatalogItem } from '../models/catalog-item';

@Injectable({
  providedIn: 'root'
})
export class CatalogService {

  readonly API_BASE:string="http://localhost:63402/api/catalog"
  constructor( private http:HttpClient) { }

  addProduct(formData:FormData):Observable<CatalogItem>{
    return this.http.post<CatalogItem>(`${this.API_BASE}/product`,formData)
  }
  getProducts():Observable<CatalogItem[]>{
    return this.http.get<CatalogItem[]>(`${this.API_BASE}`)
  }
}
