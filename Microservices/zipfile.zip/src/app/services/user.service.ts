import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import {User} from '../models/User'
import { Observable, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  readonly API_URL:string ="http://localhost:65295/api/auth"
    
  userSubject: BehaviorSubject<any>;
  currentUser: Observable<any>;
  constructor(private http:HttpClient) {
    this.userSubject = new BehaviorSubject<any>(JSON.parse(localStorage.getItem("user")));
    this.currentUser = this.userSubject.asObservable();
   }

  addUser(user:User):Observable<any>{
    return this.http.post<any>(`${this.API_URL}/register`,user);
  }

  getToken(loginData:any):Observable<any>{
    return this.http.post<any>(`${this.API_URL}/token`,loginData)
  }

  saveUserState(user) {
    delete user.password;
    localStorage.setItem("user", JSON.stringify(user));
    this.userSubject.next(user);
  }

  removeUserState() {
    localStorage.clear();
    this.userSubject.next(null);
  }

  public get User(){
    return this.userSubject.value;
  }
}
