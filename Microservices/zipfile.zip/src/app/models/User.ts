export interface User
{
    fillname:string,
    username:string,
    password:string,
    email:string,
    role:string
}